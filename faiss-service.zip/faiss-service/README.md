# interface-service

词向量服务Milvus-service的接口服务

https://zhuanlan.zhihu.com/p/642959732

# -*- coding: utf-8 -*-
# @FileName  : app.py
# @Description TODO
# @Author： yangmingxing
# @Email: yangmingxing@galaxyeye-tech.com
# @Date 11/9/22 2:10 PM
# @Version 1.0

import tornado
import tornado.ioloop
import tornado.web
import tornado.gen
import logging

logging.basicConfig(level="INFO")
logger = logging.getLogger()

from server.server import FaissService


def make_app():
    logger.info("Project is ready ...")
    return tornado.web.Application([
        (r"/faiss-service/v1/search", FaissService),
        (r"/faiss-service/v1/train", FaissService)
    ])

if __name__ == "__main__":
    app = make_app()
    app.listen(9098)
    tornado.ioloop.IOLoop.current().start()
    exit(0)

# -*- coding: utf-8 -*-
# @FileName  : __init__.py.py
# @Description TODO
# @Author： yangmingxing
# @Email: yangmingxing@galaxyeye-tech.com
# @Date 3/1/24 3:04 PM
# @Version 1.0
import faiss

def create_gpu_index_use_single_gpu(datas_embedding):
  res = faiss.StandardGpuResources()  # use a single GPU
  # 构建索引，这里我们选用暴力检索的方法FlatL2为例，L2代表构建的index采用的相似度度量方法为L2范数，即欧氏距离
  index_flat = faiss.IndexFlatL2(datas_embedding.shape[1])  # 这里必须传入一个向量的维度，创建一个空的索引
  gpu_index_flat = faiss.index_cpu_to_gpu(res, 0, index_flat)
  gpu_index_flat.add(datas_embedding)  # 把向量数据加入索引
  return gpu_index_flat

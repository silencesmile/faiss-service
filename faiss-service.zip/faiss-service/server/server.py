# -*- coding: utf-8 -*-
# @FileName  : server.py
# @Description TODO
# @Author： yangmingxing
# @Email: yangmingxing@galaxyeye-tech.com
# @Date 11/9/22 2:14 PM
# @Version 1.0
import os.path

import requests
import tornado.web
from abc import ABC
import time
import json
import tornado.gen
import tornado.concurrent

from settings import *
from tools.logger_utils import get_logger_conf
from concurrent.futures import ThreadPoolExecutor
from tools.faiss_tools import *

module_name = str(os.path.basename(__file__)).split('.')[0]
logger = get_logger_conf(log_path, module_name, 'INFO')

milvue_service_dict = {}

class FaissService(tornado.web.RequestHandler, ABC):
    # 定义线程池数量一定叫executor
    executor = ThreadPoolExecutor(100)  # 并发数量

    def initialize(self, ):
        self.faiss_index_cpu = self.faiss_load_cpu()
        self.faiss_index_gpu = self.faiss_load_gpu()


    def faiss_load_cpu(self):
      faiss_index_save_file_location = os.path.join(faiss_index_models, "tags_cpu.faiss")
      if os.path.exists(faiss_index_save_file_location):
        return faiss_index_load(faiss_index_save_file_location, "cpu")
      else:
        return None

    def faiss_load_gpu(self):
      faiss_index_save_file_location = os.path.join(faiss_index_models, "tags_gpu.faiss")
      if os.path.exists(faiss_index_save_file_location):
        return faiss_index_load(faiss_index_save_file_location, "gpu")
      else:
        return None

    def search_text(self, query, type):
      query_embedding = np.array([get_vec(query)]).astype('float32')
      s_time = time.time()
      if type == "cpu":
        distances, indices = data_recall(self.faiss_index_cpu, query_embedding, top_k=3)
      else:
        distances, indices = data_recall(self.faiss_index_gpu, query_embedding, top_k=3)

      e_time = time.time()
      diff_time = "%.5f" % (e_time - s_time)

      print(f"time_{type}:", diff_time, "\n", indices, "\n", distances)
      return {"code": 0, "message": "ok"}

    def train_text(self, param):
      type = param["type"]
      text_list = param["texts"]
      if type == "cpu":
        faiss_index = create_index_cpu(text_list)
        index_name = "tags_cpu.faiss"
      else:
        faiss_index = create_index_gpu(text_list)
        index_name = "tags_gpu.faiss"

      faiss_index_model = os.path.join(faiss_index_models, index_name)
      print(f"save_path: {faiss_index_model}")
      try:
        if type =="cpu":
            faiss_index_save(faiss_index, faiss_index_model)
        else:
            faiss_index_save(faiss_index, faiss_index_model, "gpu")
      except Exception as e:
        print("error: save")
      if self.faiss_index_cpu is None and type =="cpu":
        self.faiss_index_cpu = faiss_index

      if self.faiss_index_gpu is None and type =="gpu":
        self.faiss_index_gpu = faiss_index

      return {"code": 0, "message": "ok"}

    # 超过并发的数量，开始的会被覆盖
    @tornado.concurrent.run_on_executor
    def faiss_search(self, param):
        search_result = self.search_text(param["query"], param["type"])
        return search_result

    # 超过并发的数量，开始的会被覆盖
    @tornado.concurrent.run_on_executor
    def faiss_train(self, param):
      return self.train_text(param)

    @tornado.gen.coroutine
    def post(self):
        response_ = {}
        # logger_info = {}
        try:
            request_js = json.loads(str(self.request.body, encoding='utf-8'))
            logger.info('rcv: {} {}'.format(self.request.uri, request_js))

            if self.request.uri == '/faiss-service/v1/search':
                response_ = yield self.faiss_search(request_js)

            if self.request.uri == '/faiss-service/v1/train':

                # s_time = time.time()
                response_ = yield self.faiss_train(request_js)

                # logger_info["response"] = response_
                # e_time = time.time()
                # diff_time = "%.3f" % (e_time - s_time)
                # logger_info["request_time"] = diff_time
                # logger.info(json.dumps(response_, ensure_ascii=False))

        except json.decoder.JSONDecodeError:
            response_ = {
                "code": 13000,
                "msg": "JSONDecodeError",
            }
            logger.error(response_)

        except KeyError as e:
            response_ = {
                "code": 13001,
                "msg": f'param error:{e.args[0]}'
            }
            logger.error(response_)

        except ValueError as e:
            response_ = {
                "code": 13002,
                "msg": f'param error:{e.args[0]}'
            }
            logger.error(response_)

        except EOFError:
            response_ = {
                "code": 13004,
                "msg": "EOFError",
            }
            logger.error(response_)

        except Exception as e:
            response_ = {
                "code": 13005,
                "msg": e.args[0]
            }
            logger.error(response_)

        finally:
            self.set_header("Content-type", "application/json;charset=UTF-8")
            self.write(json.dumps(response_, ensure_ascii=False, indent=None))
            self.flush()

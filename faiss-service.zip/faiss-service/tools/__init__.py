# # -*- coding: utf-8 -*-
# # @FileName  : __init__.py.py
# # @Description TODO
# # @Author： yangmingxing
# # @Email: yangmingxing@galaxyeye-tech.com
# # @Date 11/9/22 2:10 PM
# # @Version 1.0
#
# import faiss
# import numpy as np
# from get_vec import get_vec
#
# def get_datas_embedding(datas):
#   vec_list = [get_vec(data) for data in datas]
#   return np.array(vec_list).astype('float32')
#
# def faiss_index_save(faiss_index, save_file_location):
#   faiss.write_index(faiss_index, save_file_location)
#
# def create_index(datas):
#   # 构建索引，这里我们选用暴力检索的方法FlatL2为例，L2代表构建的index采用的相似度度量方法为L2范数，即欧氏距离; IndexFlatIP:余弦相似度
#
#   index = faiss.IndexFlatIP(1024)  # 这里必须传入一个向量的维度，创建一个空的索引
#   # index = faiss.index_factory(1024, description, IndexFlatIP)
#
#   datas_embedding = get_datas_embedding(datas)
#   index.add(datas_embedding)  # 把向量数据加入索引
#   print(index.ntotal)
#
#   # 索引的保存
#   faiss_index_save(index, "/home/ymx/MyGit/faiss-service/faiss_models/demo.faiss")
#
#   return index
#
# def data_recall(faiss_index, query, top_k):
#   query_embedding = np.array([get_vec(query)]).astype('float32')
#   distances, indices = faiss_index.search(query_embedding, top_k)
#   return distances, indices
#
# def index_data_add(faiss_index, text):
#   # 新增是在原索引的基础上，按顺序增加
#   # 获得索引向量的数量
#   print(faiss_index.ntotal)
#   # data = ["小丁太好看了"]
#   # datas_embedding = get_datas_embedding(data)
#   datas_embedding = np.array([get_vec(text)]).astype('float32')
#   faiss_index.add(datas_embedding)
#   print(faiss_index.ntotal)
#   return faiss_index
#
# def index_data_delete(faiss_index, index):
#   # 删除是在原索引的基础上，按索引删除，删除后，索引的位置会移动补充，所以会导致位置的变更
#   print(faiss_index.ntotal)
#   # remove, 指定要删除的向量id，是一个np的array
#   # faiss_index.remove_ids()  # 删除id为0,1,2,3,4的向量
#   faiss_index.remove_ids(np.array([index]))
#   print(faiss_index.ntotal)
#   return faiss_index
#
# if __name__ == '__main__':
#     # faiss_index = create_index(["我喜欢小丁的文章", "我讨厌小丁的创作内容", "我非常喜欢小丁写的文章"])
#
#     # load faiss model
#     faiss_index = faiss.read_index("/home/ymx/MyGit/faiss-service/faiss_models/demo.faiss")
#
#     distances, indices = data_recall(faiss_index, "小丁的文章", 3)
#     print("最相似的向量索引：", indices)
#     print("对应的距离：", distances)
#
#     faiss_index = index_data_add(faiss_index, "小丁的文章")
#     distances, indices = data_recall(faiss_index, "小丁的文章", 3)
#     print("最相似的向量索引：", indices)
#     print("对应的距离：", distances)
#
#     faiss_index = index_data_delete(faiss_index, 0)
#     distances, indices = data_recall(faiss_index, "小丁的文章", 3)
#     print("最相似的向量索引：", indices)
#     print("对应的距离：", distances)
#

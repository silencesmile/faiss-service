# -*- coding: utf-8 -*-
# @FileName  : get_vec.py
# @Description TODO
# @Author： yangmingxing
# @Email: yangmingxing@galaxyeye-tech.com
# @Date 3/1/24 1:43 PM
# @Version 1.0
import json
import numpy as np
import requests

def get_vec(text):
  data = {
          "query": text
          }
  response = requests.post("http://172.16.10.191:9090/rag_service/tool/vector", data=json.dumps(data))
  data = json.loads(response.text)
  return np.array(data["data"])

if __name__ == '__main__':
    zxc = get_vec("你好")
    print(zxc)

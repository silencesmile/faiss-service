# -*- coding: utf-8 -*-
# @FileName  : nvidia_gpu_info.py
# @Description TODO
# @Author： yangmingxing
# @Email: yangmingxing@galaxyeye-tech.com
# @Date 3/2/24 11:25 AM
# @Version 1.0

'''
check linux-service gpu info
pip3 install nvidia-ml-py3

'''

#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/1/19 17:40
# @Author  : xiaodai
import pynvml
pynvml.nvmlInit()
handle = pynvml.nvmlDeviceGetHandleByIndex(0)# 这里的0是GPU id
meminfo = pynvml.nvmlDeviceGetMemoryInfo(handle)
print(meminfo.total) #第二块显卡总的显存大小
print(meminfo.used)#这里是字节bytes，所以要想得到以兆M为单位就需要除以1024**2
print(meminfo.free) #第二块显卡剩余显存大小
print(pynvml.nvmlDeviceGetCount())#显示有几块GPU

